        $.letItSnow('.let-it-snow', {
            stickyFlakes: 'lis-flake--js',
            makeFlakes: true,
            sticky: false
        });

            
            $('#titlehead')
               .fitText(1.3)
               .textillate({ in: { effect: 'none' }
            });

            $('#descript')
                .fitText(3)
                .textillate({ in: { effect: 'none' }
            });

            footext
            $('#footext')
                .fitText(5)
                .textillate({ in: { effect: 'none' }
            });

            $(window).resize(function(){     

                if($(window).innerWidth() <= 576) {
                        $('#descript')
                        .fitText(2.5)
                        .textillate({ in: { effect: 'none' }
                    });    
                }

                 
                if($(window).innerWidth() <= 576) {
                    $('#footext')
                    .fitText(3.5)
                    .textillate({ in: { effect: 'none' }
                });    
            }

                
         });
         
          