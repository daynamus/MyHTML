$('#sec1btns').onClick(function(){
    $('.female').addClass('animated bounce infinite easeone');
});
	
